#!/usr/bin/env node
require("./lib/cli").route(process.argv);
